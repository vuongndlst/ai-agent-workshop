"""Build a portable QTI 1.2 ZIP from single-answer multiple-choice questions.

Python 3 standard library only. No network, API key, Canvas login or publishing.
Usage: python build_qti.py quiz.json -o quiz_qti.zip
"""
import argparse, hashlib, html, json, math, re, zipfile
from pathlib import Path
from xml.etree import ElementTree as E

QTI='http://www.imsglobal.org/xsd/ims_qtiasiv1p2'
CP='http://www.imsglobal.org/xsd/imscp_v1p1'

def validate(data):
    if not isinstance(data.get('title'),str) or not data['title'].strip():raise ValueError('title must be non-empty text')
    qs=data.get('questions')
    if not isinstance(qs,list) or not qs:raise ValueError('questions must be a non-empty list')
    ids=set()
    for i,q in enumerate(qs,1):
        qid=q.get('id',f'q{i:03}')
        if not re.fullmatch(r'[A-Za-z][A-Za-z0-9_-]*',qid) or qid in ids:raise ValueError(f'Invalid/duplicate id: {qid}')
        ids.add(qid)
        if q.get('type','mcq')!='mcq':raise ValueError(f'{qid}: this builder supports mcq only; do not silently convert other types')
        if not isinstance(q.get('prompt'),str) or not q['prompt'].strip():raise ValueError(f'{qid}: prompt is empty')
        opts=q.get('options')
        if not isinstance(opts,list) or not 2<=len(opts)<=6 or any(not isinstance(x,str) or not x.strip() for x in opts):raise ValueError(f'{qid}: need 2–6 non-empty options')
        if len(set(x.strip() for x in opts))!=len(opts):raise ValueError(f'{qid}: duplicate options')
        if type(q.get('correct')) is not int or not 0<=q['correct']<len(opts):raise ValueError(f'{qid}: correct is a zero-based integer index')
        pts=q.get('points',1)
        if type(pts) not in [int,float] or not math.isfinite(pts) or pts<=0:raise ValueError(f'{qid}: points must be positive')
        if not isinstance(q.get('feedback'),str) or not q['feedback'].strip():raise ValueError(f'{qid}: add explanatory feedback')
    return len(qs)

def build(data,out):
    validate(data)
    E.register_namespace('',QTI)
    tag=lambda x:f'{{{QTI}}}{x}'
    root=E.Element(tag('questestinterop'))
    # Stable IDs support traceability. Teachers should avoid overwrite-on-import
    # unless intentionally replacing matching content.
    aid='assessment_'+hashlib.sha256(data['title'].encode()).hexdigest()[:12]
    assessment=E.SubElement(root,tag('assessment'),ident=aid,title=data['title'])
    section=E.SubElement(assessment,tag('section'),ident='root_section')
    for i,q in enumerate(data['questions'],1):
        qid=q.get('id',f'q{i:03}');item=E.SubElement(section,tag('item'),ident=qid,title=q.get('title',f'Câu {i}'))
        md=E.SubElement(E.SubElement(item,tag('itemmetadata')),tag('qtimetadata'))
        for key,value in [('question_type','multiple_choice_question'),('points_possible',str(q.get('points',1)) )]:
            f=E.SubElement(md,tag('qtimetadatafield'));E.SubElement(f,tag('fieldlabel')).text=key;E.SubElement(f,tag('fieldentry')).text=value
        presentation=E.SubElement(item,tag('presentation'))
        material=E.SubElement(presentation,tag('material'))
        E.SubElement(material,tag('mattext'),texttype='text/html').text=q.get('prompt_html') or '<p>'+html.escape(q['prompt'])+'</p>'
        response=E.SubElement(presentation,tag('response_lid'),ident='response1',rcardinality='Single')
        choice=E.SubElement(response,tag('render_choice'),shuffle='No')
        for j,opt in enumerate(q['options']):
            label=E.SubElement(choice,tag('response_label'),ident=f'answer_{j+1}')
            E.SubElement(E.SubElement(label,tag('material')),tag('mattext'),texttype='text/plain').text=opt
        processing=E.SubElement(item,tag('resprocessing'))
        outcomes=E.SubElement(processing,tag('outcomes'))
        E.SubElement(outcomes,tag('decvar'),maxvalue='100',minvalue='0',varname='SCORE',vartype='Decimal')
        # Feedback for every response.
        general=E.SubElement(processing,tag('respcondition'),attrib={'continue':'Yes'})
        E.SubElement(E.SubElement(general,tag('conditionvar')),tag('other'))
        E.SubElement(general,tag('displayfeedback'),feedbacktype='Response',linkrefid='general_feedback')
        correct=E.SubElement(processing,tag('respcondition'),attrib={'continue':'No'})
        E.SubElement(E.SubElement(correct,tag('conditionvar')),tag('varequal'),respident='response1').text=f"answer_{q['correct']+1}"
        E.SubElement(correct,tag('setvar'),action='Set',varname='SCORE').text='100'
        feedback=E.SubElement(item,tag('itemfeedback'),ident='general_feedback')
        E.SubElement(E.SubElement(E.SubElement(feedback,tag('flow_mat')),tag('material')),tag('mattext'),texttype='text/plain').text=q['feedback']
    xml=E.tostring(root,encoding='utf-8',xml_declaration=True)
    manifest=E.Element('manifest',xmlns=CP,identifier=aid+'_manifest')
    meta=E.SubElement(manifest,'metadata');E.SubElement(meta,'schema').text='IMS Content';E.SubElement(meta,'schemaversion').text='1.1.3'
    E.SubElement(manifest,'organizations')
    resource=E.SubElement(E.SubElement(manifest,'resources'),'resource',identifier=aid+'_resource',type='imsqti_xmlv1p2',href='assessment.xml')
    E.SubElement(resource,'file',href='assessment.xml')
    out=Path(out);out.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
        z.writestr('imsmanifest.xml',E.tostring(manifest,encoding='utf-8',xml_declaration=True));z.writestr('assessment.xml',xml)
    with zipfile.ZipFile(out) as z:
        if z.testzip():raise ValueError('ZIP CRC failed')
        for name in ['imsmanifest.xml','assessment.xml']:E.fromstring(z.read(name))
    return out

if __name__=='__main__':
    a=argparse.ArgumentParser(description=__doc__);a.add_argument('source');a.add_argument('-o','--output',default='quiz_qti.zip');a.add_argument('--validate-only',action='store_true');args=a.parse_args()
    data=json.loads(Path(args.source).read_text(encoding='utf-8'))
    count=validate(data)
    if not args.validate_only:print(build(data,args.output))
    print(f'Validated {count} multiple-choice questions')
