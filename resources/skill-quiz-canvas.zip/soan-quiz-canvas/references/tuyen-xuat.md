# Tuyến xuất quiz Canvas

## QTI
Canvas hỗ trợ nhập các gói QTI. Bộ này cung cấp QTI 1.2 cho trắc nghiệm một đáp án, cùng mã tạo bằng thư viện chuẩn Python 3.

- Classic Quizzes: Settings → Import Course Content → QTI .zip file → chọn gói → nhập và xem lỗi.
- New Quizzes: tạo quiz shell, vào Build và dùng chức năng Import. Tùy cấu hình trường, đường nhập hoặc chuyển đổi có thể khác. Đọc hướng dẫn đúng phiên bản.
- Kiểm tra lại tổng điểm, phản hồi, đảo đáp án, thời gian, số lần làm và thời điểm hiện đáp án sau nhập. QTI không thay việc cài đặt toàn bộ chính sách quiz.
- Nhập thử vào khóa thử nghiệm trước. Không bật ghi đè ID nếu chưa có ý định thay nội dung cũ.

## Word theo mẫu trường
DOCX trong assets và cú pháp text đi kèm là nguồn soạn cho công cụ chuyển đổi của quy trình trường. Chỉ dùng khi đã biết bộ chuyển đổi nào nhận các ký hiệu đó. Đây không phải định dạng nhập DOCX trực tiếp của Canvas chuẩn.

## Script đi kèm
`python scripts/build_qti.py assets/quiz_mau.json -o quiz_qti.zip`

Schema nguồn: title; questions gồm id, type=mcq, prompt, options, correct (chỉ số từ 0), points và feedback. prompt_html là tùy chọn cho HTML tự chứa. Không đưa ảnh/đường dẫn local không tồn tại trong gói. Script mẫu không hỗ trợ nhóm rút ngẫu nhiên, nhiều đáp án, số, tự luận hoặc tải tệp.

Nguồn chính thức: https://community.instructure.com/en/kb/articles/660996-unknown
