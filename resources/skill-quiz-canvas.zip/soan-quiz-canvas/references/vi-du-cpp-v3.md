# Ví dụ từ khóa C++ Version 3

assets/vi_du_cpp_v3.docx là nguồn Word nguyên bản Bài 2 của thầy Vương. assets/vi_du_cpp_v3_QTI.zip là gói đi kèm, có tài nguyên hình và nhóm câu. Dùng để quan sát cấu trúc thực tế và đối chiếu khi soạn.

Không dùng script MCQ tối giản để tái tạo mọi tính năng trong gói thực tế này. Script build_qti.py chỉ hỗ trợ MCQ một đáp án từ JSON. Khi có nhóm câu, hình hoặc dạng câu khác, xác định đúng tuyến chuyển đổi và kiểm tra nhập trên môi trường Canvas đang dùng.
