# Cú pháp Canvas Quiz (import từ file Word .docx)

File mẫu đầy đủ (có ví dụ sống cho từng quy tắc): `assets/mau_canvas_quiz.docx`. Đây là quy ước soạn nguồn Word của quy trình trường. Cần công cụ chuyển đổi tương ứng trước khi nhập vào Canvas. Canvas chuẩn dùng gói QTI, không nhập trực tiếp DOCX này. Phải giữ ký tự để công cụ chuyển đổi nhận dạng đúng.

## Cấu hình chung của Quiz (đầu file)

```
quiz title: <tên quiz>

quiz description: <mô tả>

shuffle answers: true

show correct answers: true

one question at a time: true
```

## Nhóm câu hỏi (Question Group / Item Bank)

Dùng khi muốn rút ngẫu nhiên N câu từ một nhóm lớn hơn:

```
GROUP

Group title: <Tên nhóm — sẽ thành tên Item Bank trên Canvas>

pick: 1

points per question: 2

- <câu hỏi 1>
- !<đáp án đúng>
- <đáp án sai>

END_GROUP
```
`pick: N` = số câu rút ngẫu nhiên từ nhóm khi học sinh làm bài.

## Các dạng câu hỏi

### 1. Trắc nghiệm 1 đáp án đúng (Multiple Choice)

```
Title: <tên câu hỏi, có thể bỏ qua — mặc định là "Question">

Points: 2   (có thể bỏ qua — mặc định là 1 điểm)

- <Nội dung câu hỏi>
- <đáp án sai>
- !<đáp án ĐÚNG — dấu "!" ngay đầu dòng, KHÔNG có khoảng trắng sau dấu "!">
- <đáp án sai>
```
- Câu hỏi và đáp án dùng **list paragraph dạng số (1.) hoặc chữ (a.)** trong Word — không dùng bullet ký hiệu tự do.
- Đáp án đúng **luôn đánh dấu bằng "!"** ngay sát đầu dòng, không cách.

### 2. Nhiều đáp án đúng (Multiple Answers)

```
- <Nội dung câu hỏi>
[*] <đáp án đúng>
[*] <đáp án đúng>
[] <đáp án sai>
```
- Đáp án dùng cặp dấu ngoặc vuông `[]` ở đầu dòng, có khoảng trắng sau `]`.
- `[*]` = đáp án đúng (dấu `*` trong ngoặc vuông).
- **Các đáp án đúng phải xếp ở đầu danh sách**, đáp án sai xếp sau.
- Không giới hạn 4 đáp án — có thể nhiều hơn.

### 3. Câu hỏi số / công thức (Numerical Answer)

```
- <Nội dung câu hỏi>
= 1.4142 +- 0.0001
```
hoặc dạng khoảng giá trị:
```
= [1.2598, 1.2600]
```
**Phải có ít nhất 1 khoảng trắng sau dấu "="**.

### 4. Trả lời ngắn (Short Answer / Fill in the blank)

```
<br><Nội dung câu hỏi>
<br><dòng tiếp theo nếu cần xuống dòng>

* <đáp án đúng 1>
* <đáp án đúng 2>
```
- Tiền tố `<br>` ở đầu dòng câu hỏi dùng để **ngắt dòng** trong nội dung câu hỏi.
- Mỗi đáp án chấp nhận được đánh dấu bằng `*`.

### 5. Tự luận (Essay)

```
- <Nội dung câu hỏi>
____
```
Dùng **ít nhất 4 dấu gạch dưới** (`____`) để báo hiệu đây là câu tự luận (không có đáp án mẫu).

### 6. Câu hỏi tải file lên (File Upload)

```
- <Nội dung câu hỏi>
^^^^
```
Dùng **ít nhất 4 dấu mũ** (`^^^^`).

### 7. Feedback (phản hồi cho từng đáp án / toàn câu)

```
- <Nội dung câu hỏi>
... <feedback chung cho cả câu hỏi>
+   <feedback khi học sinh trả lời đúng>
-   <feedback khi học sinh trả lời sai>
- <đáp án 1>
... <feedback riêng cho đáp án này>
- !<đáp án đúng>
... <feedback riêng cho đáp án đúng>
```
Tiền tố `...` = feedback chung hoặc feedback riêng theo từng đáp án (đặt ngay dưới đáp án tương ứng).

### 8. Câu hỏi có bảng dữ liệu

Có thể chèn bảng Word (markdown table khi extract) ngay trong phần nội dung câu hỏi, học sinh sẽ thấy bảng đó khi làm bài — hữu ích cho câu hỏi "đọc bảng số liệu và nhận xét".

## Quy tắc định dạng chung cần nhớ

- Numbering của câu hỏi/đáp án **có thể đổi kiểu** (a) → a., chữ thường/hoa...) miễn vẫn là list paragraph, Canvas vẫn nhận diện đúng.
- Số thứ tự câu hỏi **không cần liên tục/đúng thứ tự**.
- Ký tự đánh dấu đáp án (a, b, c, d) **không cần đúng thứ tự chữ cái**.
- Khi không đặt `Title`, Canvas tự đặt tên là "Question".
- Khi không đặt `Points`, mặc định là 1 điểm.

## Quy trình tạo Canvas Quiz mới

1. Xác định số câu, dạng câu hỏi cần (trắc nghiệm/nhiều đáp án/số/tự luận...).
2. Soạn nội dung theo đúng cú pháp trên trong file Word (dựa khung từ `assets/mau_canvas_quiz.docx`).
3. Đáp án đúng PHẢI đánh dấu đúng ký hiệu (`!` cho 1 đáp án, `[*]` cho nhiều đáp án) — đây là lỗi hay gặp nhất khi import sai.
4. Nếu cần random hoá ngân hàng câu hỏi, bọc trong `GROUP ... END_GROUP`.
