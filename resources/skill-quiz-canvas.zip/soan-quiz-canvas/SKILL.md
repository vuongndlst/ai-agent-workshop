---
name: soan-quiz-canvas
description: Soạn và rà quiz Canvas từ mục tiêu và tài liệu môn học, xuất nguồn có đáp án và QTI hoặc định dạng Word cho công cụ chuyển đổi đã xác định.
---

# Quy trình

1. Đọc mục tiêu, nguồn, đối tượng và yêu cầu đánh giá. Làm rõ số câu, dạng câu, điểm, thời gian và Classic/New Quizzes nếu điều này ảnh hưởng đầu ra.
2. Lập ma trận ngắn: mục tiêu, mức suy nghĩ, số câu, loại câu và điểm. Tránh để số câu dễ tạo quyết định phạm vi đánh giá.
3. Soạn câu hỏi có đủ dữ liệu, một cách hiểu rõ, phương án nhiễu có lý do và phản hồi giải thích. Câu cần hình/bảng phải kèm tài nguyên tự chứa.
4. Tự giải lại và đối chiếu với nguồn. Rà câu trùng, đáp án mơ hồ, gợi ý lộ đáp án và tổng điểm.
5. Chọn tuyến xuất theo references/tuyen-xuat.md. Không gọi DOCX là tệp Canvas có thể nhập trực tiếp.
6. Với trắc nghiệm một đáp án, có thể dùng scripts/build_qti.py và assets/quiz_mau.json để xuất QTI 1.2 bằng Python 3. Script chỉ hỗ trợ mcq, không tự chuyển dạng khác thành trắc nghiệm.
7. Với quy trình Word của trường đã có công cụ chuyển đổi, dùng assets/mau_canvas_quiz.docx, bản đã soạn assets/quiz_mau_da_soan.docx và references/canvas-text-truong.md. Kiểm tra list paragraph và các dấu !, [*], = hoặc ký hiệu dạng câu.
8. Kiểm tra cấu trúc ZIP/XML, số câu, đáp án, điểm và tài nguyên kèm. Sau đó hướng dẫn GV nhập vào khóa thử, Preview và thử một đáp án đúng/sai trước khi dùng.
9. Báo đúng phạm vi kiểm tra. Không khẳng định đã nhập thành công khi chưa thao tác trên Canvas. Không tự đăng hoặc giao bài.

# Đầu ra

Nguồn chỉnh sửa được, ma trận, đáp án và giải thích cho GV, tệp theo tuyến xuất đã chọn, hướng dẫn nhập và những phần chưa kiểm chứng. Đáp án GV tách khỏi học liệu HS.

# Dùng lại

Đọc references/tuyen-xuat.md khi chọn định dạng. Đọc references/canvas-text-truong.md chỉ khi dùng tuyến Word. Thông tin môn, lớp, bài và thang điểm thuộc prompt hoặc bối cảnh, không đóng cứng vào skill.


# Ví dụ thực tế

Đọc references/vi-du-cpp-v3.md khi cần mẫu Word và QTI có nhóm câu, hình từ khóa C++ Version 3. Giữ đúng phạm vi của từng tuyến xuất.
