# Dùng và sửa skill mẫu

Skill gồm SKILL.md và có thể kèm references, assets, scripts. Bộ này có hướng dẫn, tài liệu, mẫu Word/XLSX và mã Python tạo QTI trắc nghiệm đơn giản. Mã mẫu không cần API hoặc tài khoản Canvas; phần mềm xử lý Word/XLSX có thể cần được cài riêng. Đọc nội dung trước khi dùng.

## Cách bắt đầu
1. Chọn một skill phù hợp thay vì bật mọi skill cho mọi nhiệm vụ.
2. Sao chép nguyên thư mục skill vào vị trí nền tảng hỗ trợ.
3. Nêu tên skill trong yêu cầu, xác nhận Agent đã đọc đúng skill.
4. Thử bằng một nhiệm vụ nhỏ, đối chiếu kết quả với tiêu chí.
5. Sửa skill từ lỗi hoặc góp ý lặp lại, thử lại bằng bài khác.

## Ví dụ vị trí theo dự án
- Codex: .agents/skills/<ten-skill>/SKILL.md.
- Claude Code: .claude/skills/<ten-skill>/SKILL.md.
- Antigravity App/IDE: .agents/skills/<ten-skill>/SKILL.md theo tài liệu hiện hành.
- Claude trên web/Cowork: cơ chế bật skill phụ thuộc tài khoản và môi trường; không coi việc chép thư mục local là đã cài vào phiên web. Xem mục skills trong cài đặt hoặc tài liệu chính thức.

Các đường dẫn trên là ví dụ cài theo dự án. Kiểm tra lại tài liệu đúng sản phẩm và phiên bản đang sử dụng. Nội dung dùng lại được nhưng công cụ, quyền, đường dẫn và cú pháp gọi có thể khác. Skill không tự cấp quyền, không thêm công cụ còn thiếu và không phải trí nhớ tự động.

## Ví dụ yêu cầu
“Dùng skill hoc-lieu-phan-hoa để thiết kế nhiệm vụ bài 3. Đọc BOI_CANH.md và nguồn trước. Báo skill và nguồn đã dùng.”

## Tự kiểm tra skill
- Description có chỉ rõ lúc dùng không?
- Quy trình có thể áp dụng sang bài khác không?
- Có giữ các thông tin thay đổi ở prompt/bối cảnh không?
- Có tiêu chí và cách báo việc chưa làm được không?
- Có mẫu tốt và một lần thử sang bài khác không?
